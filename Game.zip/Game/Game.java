package Game;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

/**
 * Lógica do jogo.
 * O servidor chama esses métodos para validar e aplicar jogadas.
 * Clientes apenas exibem mensagens.
 */
public class Game {

    // =========================
    // Estado principal
    // =========================
    private final List<Player> players = new ArrayList<>();
    private int currentPlayerIndex = 0;

    private int bulletsInChamber;
    private int realBullets;
    private int fakeBullets;

    private final Random rng = new Random();

    private String pendingAmmoInfo = null;

    // =========================
    // Tipos de resultado do tiro
    // =========================
    public enum ShotType {
        HIT, MISS, RELOAD, INVALID
    }

    // =========================
    // Artes ASCII
    // =========================
    public static final String HIT_ART =
"⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢀⣴⢶⣶⣶⠼⣦⣤⣼⣼⡆⠀⠀⠀⠀⠀⠀⠀⠀\n" +
"⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⣠⠖⣯⠿⠟⠛⠻⢶⣿⣯⣿⣿⣃⠀⠀⠀⠀⠀⠀⠀⠀\n" +
"⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⣠⣖⣺⡿⠿⠷⠶⠒⢶⣶⠖⠀⠉⡻⢻⣿⡇⠀⠀⠀⠀⠀⠀⠀⠀\n" +
"⠀⠀⠀⠀⠀⠀⠀⠀⣴⢻⣭⣫⣿⠁⠀⠀⠀⠀⠀⠀⠀⢀⣾⠃⢀⡏⠀⠀⠀⠀⠀⠀⠀⠀⠀\n" +
"⠀⠀⠀⠀⢀⣖⡿⠋⢙⣿⠿⢿⠿⣿⡦⠄⠀⠀⠀⣠⣾⠟⠀⠀⣼⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀\n" +
"⠀⠀⢀⣰⣿⣴⣿⡿⠿⠿⠿⢿⣦⣄⠀⠀⠀⣠⣾⣿⠃⠀⢀⣸⡿⣳⣶⣲⡄⠀⠀⠀⠀⠀⠀\n" +
"⠀⠀⣾⣽⡿⣛⣵⠾⠿⠿⠷⣦⣌⠻⣷⣄⢰⣿⠟⠁⠀⢠⣾⠿⢡⣯⠸⠧⢽⣄⠀⠀⠀⠀⠀\n" +
"⠀⢸⡇⡟⣴⡿⢟⣽⣾⣿⣶⣌⠻⣧⣹⣿⡿⠋⠀⠀⠀⣾⠿⡇⣽⣿⣄⠀⠀⠉⠳⣄⢀⡀⠀\n" +
"⠀⢸⠇⢳⣿⢳⣿⣿⣿⣿⣿⣿⡆⢹⡇⣿⡇⠀⡆⣠⣼⡏⢰⣿⣿⣿⣿⣦⠀⠀⠀⠈⠳⣅⠀\n" +
"⠀⣸⡀⢸⣿⢸⣿⣿⣿⣿⣿⣿⡇⣸⡇⣿⡇⠀⡟⣻⢳⣷⣿⣿⣿⣿⣿⣿⠀⠀⠀⠀⠀⠘⣧\n" +
"⢰⡟⡿⡆⠹⣧⡙⢿⣿⣿⠿⡟⢡⣿⢷⣿⣧⠾⢠⣿⣾⣿⣿⣿⣿⣿⣿⠁⠀⠀⠀⠀⠀⠀⠘\n" +
"⠀⠻⡽⣦⠀⠈⠙⠳⢶⣦⡶⠞⢻⡟⡸⠟⠁⢠⠟⠉⠉⠙⠿⣿⣿⣿⣿⠀⠀⠀⠀⠀⠀⠀⡴\n" +
"⠀⠀⢸⣿⡇⠀⠀⣀⣠⠀⢀⡀⠸⣹⠇⠀⣰⡟⡀⠀⠈⠛⠻⢿⣻⣿⡿⠀⠀⠀⠀⠀⠀⡠⠁\n" +
"⠀⠀⢸⣿⣇⣴⢿⣿⣿⣿⣮⣿⣷⡟⠀⣰⣿⢰⠀⣀⠀⠀⠀⢀⣉⣿⡇⠀⠀⠀⠀⠀⣸⠃⠀\n" +
"⠀⠀⢸⣿⡟⣯⠸⣿⣿⣿⣿⢈⣿⡇⣼⣿⠇⣸⡦⣙⣷⣦⣴⣯⠿⠛⢷⡀⠀⠀⠀⣰⡟⠀⠀\n" +
"⠀⠀⠘⣿⣿⡸⣷⣝⠻⠟⢋⣾⣟⣰⡏⣠⣤⡟⠀⠀⠈⠉⠁⠀⠀⠀⠀⢻⣶⠀⢀⣿⠁⠀⠀\n" +
"⠀⠀⠀⢸⡿⣿⣦⣽⣛⣛⣛⣭⣾⣷⡶⠞⠋⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⣼⣿⣿⡟⠀⠀⠀⠀\n" +
"⠀⠀⠀⠀⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢀⡀⠁⢸⢻⠁⠀⠀⠀⠀\n" +
"⠀⠀⠀⠀⡿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣧⣤⣤⣀⣀⣀⣀⣀⣠⣤⠶⠛⠁⢀⣾⡟⠀⠀⠀⠀⠀\n" +
"⠀⠀⠀⠀⢿⣻⣿⣿⣿⣿⣿⣿⣎⣿⡅⠀⠈⠉⠉⠉⠉⠉⠁⠀⠀⠀⠀⣼⣿⠁⠀⠀⠀⠀⠀\n" +
"⠀⠀⠀⠀⠈⢻⣿⣿⣿⣿⣿⣿⣿⣿⣇⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢀⣠⡷⠟⠀⠀⠀⠀⠀⠀\n" +
"⠀⠀⠀⠀⠀⠀⠙⢿⣿⣿⠻⢿⣿⣿⣟⣂⣀⣀⣀⣀⣀⣀⣤⠴⠋⠁⣾⠀⠀⠀⠀⠀⠀⠀⠀\n" +
"⠀⠀⠀⠀⠀⠀⠀⠈⢻⣿⣷⣷⡄⠀⠀⠀⠉⠉⠉⠉⠉⠀⠀⠀⢀⡞⠁⠀⠀⠀⠀⠀⠀⠀⠀\n" +
"⠀⠀⠀⠀⠀⠀⠀⠀⠀⠻⣿⣿⡆⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⣠⠟⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀\n" +
"⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠈⣿⣷⣤⣤⣤⣤⣄⣤⣤⡤⠴⠞⠁⠀⠀⠀⠀⠀⠀⠀⠀";


    public static final String MISS_ART =
"⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⡀⡀⠀⢄⠀⡌⠀⡎⡆⣲⠤⠀⡀⠀⡀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀\n" +
"⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢀⠀⡀⡀⠄⠀⠢⠄⡠⣁⠁⢘⠡⣑⢺⡊⠂⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀\n" +
"⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢀⠀⠀⠀⠁⠀⣀⠀⠆⡇⡍⣇⣦⡆⠢⠶⡇⢋⢃⡖⠂⠂⠂⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀\n" +
"⠀⠀⠀⠀⠀⠀⠀⡄⢀⠁⠀⡀⠀⠀⡖⣄⡦⡢⡟⠮⡟⠋⡇⠁⠊⠄⠀⠂⢂⠊⠀⠂⠀⠄⢀⠀⠀⠀⠀⠄⠀⠀⠀⠠⠀⠀⡀⠀⠀⠀\n" +
"⠀⠀⠀⠀⠀⠀⡀⠀⡂⠀⠀⠅⠀⠀⡏⡁⡐⠙⠉⣃⣧⡛⡏⣀⢆⣡⣐⠃⡡⣄⡈⠁⣂⠁⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠄⠀⠀⠀⠀\n" +
"⠀⠀⠀⠀⠀⠈⠁⠀⠄⡀⠊⠀⠂⠋⠁⡀⢷⣁⢝⢢⡅⣓⡋⡩⢇⠒⡃⠇⢠⠁⠄⢁⠂⠄⣐⣀⢀⠀⠀⠀⠀⠀⠂⠀⠀⠀⠀⠀⠀⠀\n" +
"⠀⠀⠀⠠⠀⠅⠁⠠⠀⡈⠀⠄⡊⢒⡁⠆⣸⣇⢣⡌⣃⣹⣏⡙⣃⠅⡂⣫⠠⡤⡣⠧⡄⡁⠀⠤⠄⡠⠁⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀\n" +
"⠀⠀⠃⠀⡂⢀⡌⠄⠉⡁⠆⢀⠔⠨⡰⣃⣫⠅⠦⣧⣬⢐⣲⢋⡃⡓⠄⢽⠩⠄⠏⡄⠄⢄⠀⠔⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀\n" +
"⠠⡄⠀⠁⠀⡁⠍⣃⢄⠂⣌⣕⢁⠏⠫⠏⣁⢄⠡⢃⠙⣝⢚⡎⡓⠉⡀⠓⡤⠔⢂⡐⠀⡀⡁⠈⠀⡀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀\n" +
"⠀⠀⣀⡄⢂⡎⣠⣅⠕⠁⢃⠀⡌⣀⠅⡀⣵⡑⡮⣥⡅⠿⠓⠉⡄⡇⠂⠀⠏⡔⠀⢅⠡⡈⣉⠒⠙⠂⠈⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀\n" +
"⠀⠐⠥⠊⠙⠡⠀⠄⠬⠠⢁⠠⡄⡈⡇⣁⠄⠁⠅⠇⡅⣯⡒⢙⢣⡅⡇⠕⠃⡃⣔⠀⡀⢂⠒⠀⠀⡁⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀\n" +
"⠀⠀⠀⠀⠀⠠⠆⠈⠂⠀⠁⠲⠀⡇⡁⡂⠀⠐⣂⡇⢔⡯⣪⣑⡂⠄⢎⠁⠢⡁⢂⠈⡥⠅⡊⠀⠉⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀\n" +
"⠀⠀⠀⠀⠀⠀⣀⠀⠀⣠⠀⠁⡠⡀⢁⡆⢒⢃⣁⡀⠆⣇⠘⠡⡹⠉⡁⠄⠁⠎⢀⠀⡊⠁⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀\n" +
"⠀⠀⠀⠀⠀⠀⠀⠡⠀⠀⢀⠂⠀⠆⠇⠂⠐⠄⠀⠄⠄⣇⠱⠨⢉⡄⠆⡠⣇⠉⡃⠃⠁⡁⠈⡀⠀⠀⠂⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀\n" +
"⠀⠃⡀⠀⠀⠀⠀⡀⡀⠀⠀⠀⠀⠀⠀⠃⢯⠃⠓⠅⠄⠯⢺⢧⠈⠁⠁⠦⢀⢀⠀⠐⠄⠂⠒⠂⠊⠀⡇⢀⠁⠀⠀⠀⠀⠀⠀⠀⠀⠀\n" +
"⠀⠀⠀⠀⠀⡀⠀⠀⠂⠠⠀⠐⢠⡨⠀⡈⡴⣄⣛⠣⠒⠔⠆⢁⠄⡃⡈⠢⢀⠤⠠⡆⠐⠂⠁⠁⢂⠀⠄⡡⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀\n" +
"⠀⠀⠀⠀⠀⠁⠀⠁⠀⢀⢈⠀⠄⢀⠀⠂⢒⡀⠄⠅⠈⢖⣂⠠⡁⡨⠈⠀⠁⠡⠀⠀⠀⠂⠔⠀⠀⠀⡄⠁⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀\n" +
"⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠂⠀⠀⡋⠀⠀⠰⢁⠄⢀⠄⠏⠀⢀⠁⠂⢀⠁⠠⠈⠈⠀⢀⠀⠀⠀⠂⠈⠀⠀⠐⠀⣀⠀⠀⠀⠀⠀⠀⠀\n" +
"⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠐⠀⠀⠋⠀⠀⠁⠀⠊⡃⠀⠂⠢⠡⠄⠀⠠⠈⠂⠀⡀⠀⠀⠈⠀⠀⠀⠀⠀⡀⠀⠂⠀⠀⠀⠀⠀⠀⠀\n" +
"⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢀⠀⠀⠀⠀⠀⠁⠁⠀⢁⠀⠀⠀⡀⠀⠀⠀⠠⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀\n";


    // =========================
    // Jogadores
    // =========================
    public void addPlayer(Player player) { players.add(player); }
    public List<Player> getPlayers() { return players; }
    public int getCurrentPlayerIndex() { return currentPlayerIndex; }
    public Player getCurrentPlayer() { return players.get(currentPlayerIndex); }

    // =========================
    // Início da partida
    // =========================
    public void resetMatch() {
        for (Player p : players) p.reset();
        currentPlayerIndex = 0;
        setupChamber();
        pendingAmmoInfo = getAmmoInfoString("🎮 Início da partida");
    }

    private void setupChamber() {
        bulletsInChamber = 6;
        realBullets = 2 + rng.nextInt(3); // 2..4
        fakeBullets = bulletsInChamber - realBullets;
    }

    public int getBulletsInChamber() {
        return bulletsInChamber;
    }

    private String getAmmoInfoString(String prefix) {
        return prefix + " | Munição: ✅ " + realBullets + " reais, ❌ " + fakeBullets + " falsas.";
    }

    public String consumePendingAmmoInfo() {
        String msg = pendingAmmoInfo;
        pendingAmmoInfo = null;
        return msg;
    }

    // =========================
    // Estado
    // =========================
    public String getStateString() {
        StringBuilder sb = new StringBuilder();
        sb.append("\n--- STATUS DOS JOGADORES ---\n");
        for (int i = 0; i < players.size(); i++) {
            Player p = players.get(i);
            sb.append(i + 1).append(") ")
              .append(p.getName())
              .append(" | Vida: ").append(p.getLife())
              .append(p.isAlive() ? "" : " ☠")
              .append("\n");
        }
        sb.append("Balas restantes: ").append(bulletsInChamber).append("\n");
        return sb.toString();
    }

    // =========================
    // Validação
    // =========================
    public String validateShot(int shooterIndex, int targetIndex) {
        if (shooterIndex != currentPlayerIndex) return "ERRO: Não é sua vez.";
        if (targetIndex < 0 || targetIndex >= players.size()) return "ERRO: Alvo inválido.";
        if (!players.get(shooterIndex).isAlive()) return "ERRO: Você está morto.";
        if (!players.get(targetIndex).isAlive()) return "ERRO: O alvo já está morto.";
        return null;
    }

    // =========================
    // Resultado do tiro
    // =========================
    public static class ShotResult {
        public final String message;
        public final boolean extraTurn;
        public final ShotType type;

        public ShotResult(String message, boolean extraTurn, ShotType type) {
            this.message = message;
            this.extraTurn = extraTurn;
            this.type = type;
        }
    }

    // =========================
    // Processa tiro
    // =========================
    public ShotResult processShot(int shooterIndex, int targetIndex) {

        String validation = validateShot(shooterIndex, targetIndex);
        if (validation != null) {
            return new ShotResult(validation, true, ShotType.INVALID);
        }

        if (bulletsInChamber == 0) {
            setupChamber();
            pendingAmmoInfo = getAmmoInfoString("🔄 Recarregou");
            return new ShotResult("🔫 Pente vazio! Recarregando...", true, ShotType.RELOAD);
        }

        Player shooter = players.get(shooterIndex);
        Player target = players.get(targetIndex);

        bulletsInChamber--;

        int total = realBullets + fakeBullets;
        boolean hit = rng.nextInt(total) < realBullets;

        if (hit) {
            realBullets--;
            target.loseLife();
            return new ShotResult("💥 BANG! " + shooter.getName() + " atirou em " + target.getName(), false, ShotType.HIT);
        } else {
            fakeBullets--;
            boolean extra = shooterIndex == targetIndex;
            return new ShotResult("😅 CLICK! " + shooter.getName() + " errou." , extra, ShotType.MISS);
        }
    }

    // =========================
    // Turnos
    // =========================
    public void advanceTurn() {
        do {
            currentPlayerIndex = (currentPlayerIndex + 1) % players.size();
        } while (!players.get(currentPlayerIndex).isAlive());
    }

    public boolean isGameOver() {
        return players.stream().filter(Player::isAlive).count() <= 1;
    }

    public int getWinnerIndexOrMinus1() {
        for (int i = 0; i < players.size(); i++) {
            if (players.get(i).isAlive()) return i;
        }
        return -1;
    }
}
